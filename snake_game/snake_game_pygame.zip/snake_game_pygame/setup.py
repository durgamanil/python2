
import cx_Freeze

executable = [cx_Freeze.Executable("snake_game.py")]

#os.environ['TCL_LIBRARY']=r'C:\Python27\tcl\tcl8.5'
#os.environ['TK_LIBRARY']=r'C:\Python27\tcl\tk8.5'

#os.environ


cx_Freeze.setup(name="oldsnake",
                
                options = {
                        
                        "build_exe":{
                                
                                "packages":["pygame"],
                                "include_files":["snakeheadnew.png","apple1.png"],
                                
                                
                                },
                        },
                description = "OldSnake Game: Funny Game",
                executables = executable
                                
                        
                
                )